<footer class="site-footer py-4 border-top mt-5">
  <div class="container text-center">
    <small class="text-muted">
      © <?= date('Y'); ?> Test Project
    </small>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
