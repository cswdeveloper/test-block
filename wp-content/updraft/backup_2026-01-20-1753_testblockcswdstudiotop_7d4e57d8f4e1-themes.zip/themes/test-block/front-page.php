<?php
/**
 * Front Page Template
 */

get_header();
?>

<main id="primary" class="site-main">

    <div class="container">

        <div class="row">
            <div class="col-12">

                <header class="page-header mb-4">
                    <h1 class="page-title">
                        <?php the_title(); ?>
                    </h1>
                </header>


                <?php
                if (have_posts()):
                    while (have_posts()):
                        the_post();
                        the_content(); // Gutenberg + ACF Blocks
                    endwhile;
                endif;
                ?>

            </div>
        </div>

    </div>

</main>

<?php get_footer(); ?>